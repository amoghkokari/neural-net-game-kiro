🎮 Neural Network Adventure RPG - Test Version

QUICK START:
1. Double-click "Neural Network Adventure.app" to start playing
2. If you see a security warning:
   - Go to System Preferences → Security & Privacy
   - Click "Open Anyway" to allow the app

WHAT TO TEST:
✅ Game starts without errors
✅ Menu navigation works (arrow keys)
✅ Level 1 (Neuron Academy) loads and plays
✅ Parameter adjustment works (left/right to select, up/down to adjust)
✅ Boss battle works (press 1-4 to answer questions)
✅ Audio narration works (Tensor speaks)
✅ Game runs smoothly (60 FPS)

CONTROLS:
- Arrow Keys: Navigate menus and adjust parameters
- SPACE/ENTER: Continue dialogue, confirm actions
- 1-4: Answer quiz questions in boss battles
- ESC: Go back/exit
- R: Reset parameters in challenges

FEEDBACK NEEDED:
- Does the game start properly?
- Are the controls intuitive?
- Is the learning progression clear?
- Any bugs or crashes?
- Overall fun factor?

Send feedback to: [your-email]

Thanks for testing! 🧠🎮✨
